# self-bot python

ptit selfbot en python avec plusieurs commandes que j'ai codé pour tester des trucs.

## ⚙️ ce que ça fait

- spam msg
- changer le status
- envoyer des embeds
- etc...

## ▶️ comment le lancer

1. faut avoir **Python 3** installé
2. installe les modules :
   ```bash
   pip install -r requirements.txt
ensuite tu lances le script : python main.py
